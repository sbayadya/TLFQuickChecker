"""Recompute the ADSL-driven cells of Table 14-1.01 and Table 14-2.01 from adsl.xpt.

Usage:  python3 verify_adsl.py
Needs:  pip install pyreadstat pandas
"""
import pyreadstat

ARMS = ["Placebo", "Xanomeline Low Dose", "Xanomeline High Dose"]

df, _ = pyreadstat.read_xport("adam/adsl.xpt")


def row(label, mask):
    counts = [int((mask & (df.TRT01P == a)).sum()) for a in ARMS]
    total = int(mask.sum())
    ns = [int((df.TRT01P == a).sum()) for a in ARMS]
    cells = " ".join(f"{c:4d} ({round(100*c/n):3d}%)" for c, n in zip(counts, ns))
    print(f"  {label:22s} {cells}  {total:4d} ({round(100*total/len(df)):3d}%)")


print("Table 14-1.01  Summary of Populations")
print(f"  {'':22s} {'Placebo':>10s} {'Xan Low':>10s} {'Xan High':>10s} {'Total':>10s}")
for label, m in [
    ("Intent-To-Treat (ITT)", df.ITTFL == "Y"),
    ("Safety", df.SAFFL == "Y"),
    ("Efficacy", df.EFFFL == "Y"),
    ("Complete Week 24", df.COMP24FL == "Y"),
    ("Complete Study", df.DISCONFL != "Y"),
]:
    row(label, m)

print("\nTable 14-2.01  Summary of Demographic and Baseline Characteristics (continuous)")
for var, label in [
    ("AGE", "Age (y)"),
    ("MMSETOT", "MMSE"),
    ("DURDIS", "Duration of disease"),
    ("EDUCLVL", "Years of education"),
    ("WEIGHTBL", "Baseline weight(kg)"),
    ("HEIGHTBL", "Baseline height(cm)"),
    ("BMIBL", "Baseline BMI"),
]:
    print(f"  {label}")
    for a in ARMS:
        s = df.loc[df.TRT01P == a, var].dropna()
        print(f"    {a:22s} n={len(s):3d}  mean={s.mean():7.1f}  sd={s.std():6.2f}"
              f"  median={s.median():7.1f}  min={s.min():6.1f}  max={s.max():6.1f}")

print("\nTable 14-2.01  categorical")


def cat(label, series, order=None):
    print(f"  {label}")
    levels = order or sorted(series.dropna().unique())
    for lv in levels:
        counts = [int(((df.TRT01P == a) & (series == lv)).sum()) for a in ARMS]
        print(f"    {str(lv):26s} " + " ".join(f"{c:4d}" for c in counts)
              + f"  {sum(counts):5d}")


cat("Pooled age group", df.AGEGR1, ["<65", "65-80", ">80"])
cat("Sex", df.SEX, ["M", "F"])
race = df.apply(
    lambda r: "Hispanic" if r.ETHNIC == "HISPANIC OR LATINO"
    else {"WHITE": "Caucasian", "BLACK OR AFRICAN AMERICAN": "African Descent"}.get(r.RACE, "Other"),
    axis=1)
cat("Race (Origin), derived", race, ["Caucasian", "African Descent", "Hispanic", "Other"])
cat("Duration of disease group", df.DURDSGR1, ["<12", ">=12"])
cat("Baseline BMI group", df.BMIBLGR1, ["<25", "25-<30", ">=30"])
