# CDISCPILOT01 — ADSL, TLF shells and TLF outputs from one study

A matched set for testing a TLF checker: one study, one ADSL, four TLF outputs, and a
shell for each output.

**Study:** CDISCPILOT01 — *Safety and Efficacy of the Xanomeline Transdermal Therapeutic
System (TTS) in Patients with Mild to Moderate Alzheimer's Disease*. Phase 2, randomized,
double-blind, placebo-controlled, parallel group. 254 subjects: Placebo (86), Xanomeline
Low Dose (84), Xanomeline High Dose (84).

This is the CDISC SDTM/ADaM Pilot Project study — the de facto public reference dataset in
clinical programming (the "xanomeline" data used by pharmaverse, PHUSE Test Data Factory,
and the R Consortium FDA pilot submissions). The data is synthetic.

## Contents

```
adam/
  adsl.xpt                                    subject-level analysis dataset (254 x 48), SAS V5 transport
  adsl.csv                                    same data as CSV, for convenience
  adsl-dataset-json.json                      same data as CDISC Dataset-JSON
  define.xml                                  define-XML for the full ADaM package (ADSL and others)

tlf/                                          real outputs, extracted page-for-page from the CSR
  t14-1-01-summary-of-populations.pdf         Table 14-1.01, 1 page,  ADSL only
  t14-2-01-demographics-baseline.pdf          Table 14-2.01, 3 pages, ADSL only
  t14-3-01-primary-adascog-week24-locf.pdf    Table 14-3.01, 1 page,  ADSL + ADQSADAS
  f14-1-time-to-dermatologic-event.pdf        Figure 14-1,   1 page,  ADSL + ADTTE (KM plot)

shells/
  shells-cdiscpilot01.pdf                     shell document, one shell per output above
  shells-cdiscpilot01.json                    same shells, machine-readable

extra/                                        modern outputs for the same study, R Consortium FDA pilot 1
  rconsortium-tlf-primary.pdf                 Table 14-3.01 rebuilt in R
  rconsortium-tlf-efficacy.pdf                ANCOVA of change from baseline at week 20
  rconsortium-tlf-kmplot.pdf                  KM plot, time to first dermatologic event
  rconsortium-tlf-demographic.out             demographics as monospaced text (.out)

verify_adsl.py                                recomputes the ADSL-driven tables from adsl.xpt
```

## About the shells

No sponsor published shells for this study, so the shells here were **reconstructed from the
final outputs**: row order, column order, decimal precision, footnote text and page breaks
match the PDFs in `tlf/` exactly, with numeric cells masked as placeholders.

Placeholder key: `xx` integer, `xx.x` / `xx.xx` decimals, `(xx%)` percentage, `x.xxx` /
`x.xxxx` p-value. Placeholder width shows the maximum field width, not a fixed digit count.

Each shell also carries the population flag, source datasets, treatment variable, and
programming notes — including the derivations that are *not* one-to-one with ADSL variables,
which is usually where a checker earns its keep:

- **Complete Study** (T14-1.01) counts `DISCONFL ne 'Y'`, not `DISCONFL = 'Y'`.
- **Race (Origin)** (T14-2.01) is derived from `RACE` *and* `ETHNIC`, not from `RACE` alone.
- **n per parameter** (T14-2.01) can be below the column N — baseline weight and BMI have
  n=83 in the Xanomeline Low Dose column.
- **Column N** in T14-3.01 is the Efficacy population (79 / 81 / 74), not the ITT N.

## Ground truth from ADSL

Every ADSL-driven number in `tlf/` reproduces from `adam/adsl.xpt`. Run `python3 verify_adsl.py`
(needs `pyreadstat` and `pandas`). Key values:

| Population | Placebo | Xan Low | Xan High | Total |
|---|---|---|---|---|
| ITT (`ITTFL='Y'`) | 86 | 84 | 84 | 254 |
| Safety (`SAFFL='Y'`) | 86 | 84 | 84 | 254 |
| Efficacy (`EFFFL='Y'`) | 79 | 81 | 74 | 234 |
| Complete Week 24 (`COMP24FL='Y'`) | 60 | 28 | 30 | 118 |
| Complete Study (`DISCONFL ne 'Y'`) | 58 | 25 | 27 | 110 |

Age: 75.2 / 75.7 / 74.4 mean, SD 8.59 / 8.29 / 7.89. Sex male: 33 / 34 / 44.
Race: Caucasian 218, African Descent 23, Hispanic 12, Other 1.

Two cells differ from the CSR by one unit in the last decimal because SAS and Python round
`.x5` differently: placebo baseline weight median (60.6 vs 60.55) and placebo duration of
disease mean (42.7 vs 42.65). Worth knowing before you treat them as checker failures.

## Provenance and licence

- `adam/`, `tlf/` — [CDISC SDTM/ADaM Pilot Project](https://github.com/cdisc-org/sdtm-adam-pilot-project).
  The `tlf/` PDFs are pages 43, 46–48, 49 and 151 of that project's clinical study report
  (`cdiscpilot01.pdf`), split out one output per file. Content unmodified.
- `extra/` — [R Consortium submissions-pilot1](https://github.com/RConsortium/submissions-pilot1)
  (Apache 2.0), built on the same study data.
- `shells/`, `verify_adsl.py`, this README — reconstructed for this bundle.

The CDISC pilot data is published for public use with a website disclaimer; check the
disclaimer PDF in the source repo before redistributing.
